/******************************************************************************

Programa que calcula la nota final 
Desarrollado online 
Autho:todos 
fecha: abril 5/2021

*******************************************************************************/

#include <stdio.h>
#include <iostream>
#include <math.h>
using namespace std;

int main()

{  float n1,n2,n3,n4; //notas
   float total_notas;
   cout << "ingrese n1 ------>";
   cin>> n1;
   cout<< "ingrese n2  ------>";
   cin>> n2;
   cout<< "ingrese n3  ------>";
   cin>> n3;
   cout<< "ingrese n4  ------>";
   cin>> n4;
   total_notas= (n1+n2+n3+n4)/4;
   cout<< "la nota final es ------->"<<total_notas;
    

     return 0; 
}  
     
